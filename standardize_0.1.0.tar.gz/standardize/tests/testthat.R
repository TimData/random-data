library(testthat)
library(standardize)

test_check("standardize")
